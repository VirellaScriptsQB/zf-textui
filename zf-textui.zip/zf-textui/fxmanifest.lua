fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'zf-textui'
author 'Virella.Scripts'
description 'Sleek no-blur TextUI for ZF scripts (exports + events)'
version '1.0.0'

ui_page 'html/index.html'

files {
  'html/index.html',
  'html/style.css',
  'html/app.js'
}

-- Keep these editable under escrow
escrow_ignore {
  'client/main.lua',
  'html/index.html',
  'html/style.css',
  'html/app.js'
}

client_scripts {
  'client/main.lua'
}
