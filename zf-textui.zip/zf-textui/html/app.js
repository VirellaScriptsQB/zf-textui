const wrap = document.getElementById('wrap');
const textEl = document.getElementById('text');
const keyEl = document.getElementById('key');

function setPos(position){
  wrap.classList.remove('pos-left','pos-right','pos-top','pos-bottom');
  wrap.classList.add(`pos-${position}`);
}

function setTheme({ accent, bg, fg }){
  if (accent) document.documentElement.style.setProperty('--accent', accent);
  if (bg) document.documentElement.style.setProperty('--bg', bg);
  if (fg) document.documentElement.style.setProperty('--fg', fg);
}

function apply(data){
  if (typeof data.text === 'string') textEl.textContent = data.text;

  if (data.key){
    keyEl.style.display = 'grid';
    keyEl.textContent = String(data.key).toUpperCase();
  } else {
    keyEl.style.display = 'none';
  }

  if (data.position) setPos(data.position);
  setTheme(data);
}

window.addEventListener('message', (event) => {
  const { action, data } = event.data || {};
  if (!action) return;

  if (action === 'show'){
    apply(data || {});
    wrap.classList.remove('hidden');
  } else if (action === 'hide'){
    wrap.classList.add('hidden');
  } else if (action === 'update'){
    apply(data || {});
  } else if (action === 'theme'){
    setTheme(data || {});
  }
});
