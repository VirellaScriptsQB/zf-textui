-- zf-textui (client-only)
-- Simple NUI TextUI + zf-notify test feedback (auto-detected)

local isOpen = false
local showingProx = false

local current = {
  text = '',
  key = nil,
  position = 'left', -- left/right/top/bottom
  accent = '#8b5cf6',
  bg = 'rgba(18,18,26,.92)',
  fg = '#ffffff'
}

-- =========================
-- Notify helper (zf-notify if running)
-- =========================
local function Notify(title, message, ntype, duration)
  title = title or 'ZF'
  message = message or ''
  ntype = ntype or 'info'
  duration = duration or 2500

  if GetResourceState('zf-notify') == 'started' then
    exports['zf-notify']:Notify({
      title = title,
      message = message,
      type = ntype,
      duration = duration
    })
  else
    print(('[zf-textui] %s: %s'):format(title, message))
  end
end

local function send(action, payload)
  SendNUIMessage({
    action = action,
    data = payload or {}
  })
end

local function normalizeOptions(opts)
  opts = opts or {}

  -- allow: ShowTextUI("Hello", "E")
  if type(opts) == 'string' then
    opts = { key = opts }
  end

  local out = {
    text = opts.text or current.text or '',
    key = opts.key,
    position = opts.position or current.position or 'left',
    accent = opts.accent or current.accent or '#8b5cf6',
    bg = opts.bg or current.bg or 'rgba(18,18,26,.92)',
    fg = opts.fg or current.fg or '#ffffff',
  }

  local p = tostring(out.position):lower()
  if p == 'top-center' or p == 'topcenter' then p = 'top' end
  if p == 'bottom-center' or p == 'bottomcenter' then p = 'bottom' end
  if p ~= 'left' and p ~= 'right' and p ~= 'top' and p ~= 'bottom' then
    p = 'left'
  end
  out.position = p

  return out
end

local function applyCurrent(data)
  current.text = data.text or current.text or ''
  current.key = data.key
  current.position = data.position or current.position or 'left'
  current.accent = data.accent or current.accent or '#8b5cf6'
  current.bg = data.bg or current.bg or 'rgba(18,18,26,.92)'
  current.fg = data.fg or current.fg or '#ffffff'
end

-- =========================
-- Public API
-- =========================

local function Show(text, opts)
  opts = opts or {}
  if type(opts) ~= 'table' then opts = { key = opts } end

  local data = normalizeOptions({
    text = text or current.text or '',
    key = opts.key,
    position = opts.position,
    accent = opts.accent,
    bg = opts.bg,
    fg = opts.fg
  })

  applyCurrent(data)
  isOpen = true
  send('show', data)
end

local function Hide()
  isOpen = false
  send('hide', {})
end

local function Update(text, opts)
  opts = opts or {}
  if type(opts) ~= 'table' then opts = { key = opts } end

  if not isOpen then
    Show(text, opts)
    return
  end

  local data = normalizeOptions({
    text = text or current.text or '',
    key = (opts.key ~= nil) and opts.key or current.key,
    position = opts.position or current.position,
    accent = opts.accent or current.accent,
    bg = opts.bg or current.bg,
    fg = opts.fg or current.fg,
  })

  applyCurrent(data)
  send('update', data)
end

local function SetTheme(theme)
  theme = theme or {}
  current.accent = theme.accent or current.accent
  current.bg = theme.bg or current.bg
  current.fg = theme.fg or current.fg

  if isOpen then
    send('theme', { accent = current.accent, bg = current.bg, fg = current.fg })
  end
end

-- =========================
-- Exports
-- =========================
exports('ShowTextUI', Show)
exports('HideTextUI', Hide)
exports('UpdateTextUI', Update)
exports('IsTextUIOpen', function() return isOpen end)
exports('SetTextUITheme', SetTheme)

-- =========================
-- Client events (optional)
-- =========================
RegisterNetEvent('zf-textui:client:show', function(text, opts) Show(text, opts) end)
RegisterNetEvent('zf-textui:client:hide', function() Hide() end)
RegisterNetEvent('zf-textui:client:update', function(text, opts) Update(text, opts) end)
RegisterNetEvent('zf-textui:client:theme', function(theme) SetTheme(theme) end)

-- =========================
-- Test Commands (with zf-notify feedback)
-- =========================

local function joinArgs(args, startIndex)
  local out = {}
  for i = startIndex or 1, #args do
    out[#out + 1] = args[i]
  end
  return table.concat(out, " ")
end

-- /zftxtcheck: validates NUI + zf-notify presence and shows current state
RegisterCommand('zftxtcheck', function()
  local nuiOk = (GetCurrentResourceName() ~= nil) -- cheap sanity check; NUI itself is file-based
  local notifyState = GetResourceState('zf-notify')

  Notify('zf-textui', ('NUI: %s | zf-notify: %s | open: %s'):format(
    nuiOk and 'ok' or 'unknown',
    notifyState,
    tostring(isOpen)
  ), 'info', 4000)
end, false)

-- /zftxt: auto demo (shows -> updates -> hides) and notifies results
RegisterCommand('zftxt', function()
  Notify('zf-textui', 'Starting TextUI demo…', 'info', 2000)

  Show('Open the locker', { key = 'E', position = 'left' })
  Notify('zf-textui', 'ShowTextUI called (should be visible).', 'success', 1800)

  SetTimeout(2000, function()
    Update('Hold E to search', { key = 'E' })
    Notify('zf-textui', 'UpdateTextUI called (text should change).', 'success', 1800)
  end)

  SetTimeout(4500, function()
    Hide()
    Notify('zf-textui', 'HideTextUI called (should disappear).', 'success', 2200)
  end)
end, false)

-- /zftxtshow [key] [text...]
RegisterCommand('zftxtshow', function(_, args)
  local key = args[1]
  local text = joinArgs(args, 2)
  if text == '' then text = 'Press E to interact' end

  Show(text, { key = key })
  Notify('zf-textui', ('Show: "%s" [%s]'):format(text, key or 'no-key'), 'success', 2500)
end, false)

-- /zftxtupdate [key] [text...]
RegisterCommand('zftxtupdate', function(_, args)
  local key = args[1]
  local text = joinArgs(args, 2)
  if text == '' then text = 'Updated interaction text' end

  Update(text, { key = (key and key ~= '') and key or nil })
  Notify('zf-textui', ('Update: "%s"'):format(text), 'success', 2500)
end, false)

-- /zftxthide
RegisterCommand('zftxthide', function()
  Hide()
  Notify('zf-textui', 'Hidden.', 'info', 1500)
end, false)

-- /zftxtpos <left|right|top|bottom>
RegisterCommand('zftxtpos', function(_, args)
  local pos = (args[1] or 'left'):lower()
  if not isOpen then
    Show('Press E to interact', { key = 'E', position = pos })
  else
    Update(current.text ~= '' and current.text or 'Press E to interact', { position = pos })
  end
  Notify('zf-textui', ('Position set to: %s'):format(pos), 'info', 2000)
end, false)

-- /zftxttheme <#hex>
RegisterCommand('zftxttheme', function(_, args)
  local accent = args[1] or '#8b5cf6'
  SetTheme({ accent = accent })
  Notify('zf-textui', ('Accent set to: %s'):format(accent), 'info', 2200)
end, false)

-- =========================
-- Optional: Proximity Marker Demo (best real test)
-- Toggle with /zftxtprox
-- =========================

local proxEnabled = false
local testPoint = vec3(441.2, -981.9, 30.7)
local testRadius = 2.0

RegisterCommand('zftxtprox', function()
  proxEnabled = not proxEnabled
  if proxEnabled then
    Notify('zf-textui', 'Proximity demo enabled. Walk to the marker.', 'success', 3500)
  else
    Notify('zf-textui', 'Proximity demo disabled.', 'info', 2000)
    showingProx = false
    Hide()
  end
end, false)

CreateThread(function()
  while true do
    if not proxEnabled then
      Wait(500)
    else
      local ped = PlayerPedId()
      local pcoords = GetEntityCoords(ped)
      local dist = #(pcoords - testPoint)

      DrawMarker(
        1,
        testPoint.x, testPoint.y, testPoint.z - 1.0,
        0.0,0.0,0.0,
        0.0,0.0,0.0,
        1.0, 1.0, 0.5,
        139, 92, 246, 180,
        false, false, 2, false, nil, nil, false
      )

      if dist <= testRadius then
        if not showingProx then
          showingProx = true
          Show('Press E to interact', { key = 'E', position = 'left' })
          Notify('zf-textui', 'TextUI shown (inside radius).', 'success', 1800)
        end

        if IsControlJustPressed(0, 38) then -- E
          Notify('zf-textui', 'E pressed ✅ (interaction works).', 'success', 1800)
          Update('Nice! Interaction registered.', { key = 'E' })
        end
      else
        if showingProx then
          showingProx = false
          Hide()
          Notify('zf-textui', 'TextUI hidden (left radius).', 'info', 1500)
        end
      end

      Wait(0)
    end
  end
end)
